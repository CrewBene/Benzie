﻿// <PackageReference Include="WebSocketSharp-netstandard" Version="1.0.1" />
using System.Net;
using WebSocketSharp;
using WebSocketSharp.Server;

const string service = "/benzie";
const int port = 8090;

WebSocketServer server = new(IPAddress.Any, 8090);
server.AddWebSocketService<Echo>(service);
server.Start();

Console.WriteLine($"Benzie-Server (port '{port}' service '{service}')");
while (true)
{
    Console.ReadKey();
    Echo.Logging = !Echo.Logging;
    if (Echo.Logging)
    {
        Console.WriteLine("Logging enabled");
    }
    else
    {
        Console.WriteLine("Logging disabled");
    }
}

internal class Echo : WebSocketBehavior
{
    internal static bool Logging { get; set; }

    protected override void OnMessage(MessageEventArgs e)
    {
        Sessions.Broadcast(e.Data);
        if (Logging)
        {
            Console.WriteLine(e.Data);
        }
    }
}
